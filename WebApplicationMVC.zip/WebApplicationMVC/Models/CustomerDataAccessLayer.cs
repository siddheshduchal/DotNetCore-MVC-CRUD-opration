using System;  
using System.Collections.Generic;  
using System.Data;  
using System.Data.SqlClient;  
using System.Linq;  
using System.Threading.Tasks;  
  
namespace WebApplicationMVC.Models  
{  
    public class CustomerDataAccessLayer  
    {  
        string connectionString = "Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=Employee;Data Source=LAPTOP_208\\SQLEXPRESS";  
  
        //To View all Customer details    
        public IEnumerable<Customer> GetAllCustomer()  
        {  
            List<Customer> lstcustomer = new List<Customer>();  
  
            using (SqlConnection con = new SqlConnection(connectionString))  
            {  
                SqlCommand cmd = new SqlCommand("spGetAllCustomer", con);  
                cmd.CommandType = CommandType.StoredProcedure;  
  
                con.Open();  
                SqlDataReader rdr = cmd.ExecuteReader();  
  
                while (rdr.Read())  
                {  
                    Customer cust = new Customer();

                    cust.ID = Convert.ToInt32(rdr["CustomerID"]);
                    cust.Name = rdr["Name"].ToString();
                    cust.Gender = rdr["Gender"].ToString();
                    cust.Address = rdr["Address"].ToString();
                    cust.City = rdr["City"].ToString();

                    lstcustomer.Add(cust);  
                }  
                con.Close();  
            }  
            return lstcustomer;  
        }

        //To Add new cust record    
        public void AddCustomer(Customer customer)  
        {  
            using (SqlConnection con = new SqlConnection(connectionString))  
            {  
                SqlCommand cmd = new SqlCommand("spAddCustomer", con);  
                cmd.CommandType = CommandType.StoredProcedure;  
  
                cmd.Parameters.AddWithValue("@Name", customer.Name);  
                cmd.Parameters.AddWithValue("@Gender", customer.Gender);  
                cmd.Parameters.AddWithValue("@Address", customer.Address);  
                cmd.Parameters.AddWithValue("@City", customer.City);  
  
                con.Open();  
                cmd.ExecuteNonQuery();  
                con.Close();  
            }  
        }

        //To Update the records of a particluar customer  
        public void UpdateCustomer(Customer customer)  
        {  
            using (SqlConnection con = new SqlConnection(connectionString))  
            {  
                SqlCommand cmd = new SqlCommand("spUpdateCustomer", con);  
                cmd.CommandType = CommandType.StoredProcedure;  
  
                cmd.Parameters.AddWithValue("@CustId", customer.ID);  
                cmd.Parameters.AddWithValue("@Name", customer.Name);  
                cmd.Parameters.AddWithValue("@Gender", customer.Gender);  
                cmd.Parameters.AddWithValue("@Address", customer.Address);  
                cmd.Parameters.AddWithValue("@City", customer.City);  
  
                con.Open();  
                cmd.ExecuteNonQuery();  
                con.Close();  
            }  
        }

        //Get the details of a particular customer  
        public Customer GetCustomerData(int? id)  
        {  
            Customer customer = new Customer();  
  
            using (SqlConnection con = new SqlConnection(connectionString))  
            {  
                string sqlQuery = "SELECT * FROM tblCustomer WHERE customerID= " + id;  
                SqlCommand cmd = new SqlCommand(sqlQuery, con);  
  
                con.Open();  
                SqlDataReader rdr = cmd.ExecuteReader();  
  
                while (rdr.Read())  
                {
                    customer.ID = Convert.ToInt32(rdr["CustomerID"]);
                    customer.Name = rdr["Name"].ToString();
                    customer.Gender = rdr["Gender"].ToString();
                    customer.Address = rdr["Address"].ToString();
                    customer.City = rdr["City"].ToString();  
                }  
            }  
            return customer;  
        }

        //To Delete the record on a particular customer  
        public void DeleteCustomer(int? id)  
        {  
  
            using (SqlConnection con = new SqlConnection(connectionString))  
            {  
                SqlCommand cmd = new SqlCommand("spDeleteCustomer", con);  
                cmd.CommandType = CommandType.StoredProcedure;  
  
                cmd.Parameters.AddWithValue("@CustId", id);  
  
                con.Open();  
                cmd.ExecuteNonQuery();  
                con.Close();  
            }  
        }  
    }  
}  